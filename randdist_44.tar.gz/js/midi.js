"use strict"; 


// MIDI

function verify_midi_exists() {
  // request MIDI access
  if(navigator.requestMIDIAccess){
    global_midi_exists = true;
    // Speak("midi exists");			
    navigator.requestMIDIAccess({sysex: false}).then(onMIDISuccess, onMIDIFailure);
  }
  else {
    global_midi_exists = false;
    Speak("midi does not exist");
  }
}


function onMIDIFailure(e){
    Speak("No access to MIDI devices or your browser doesn't support WebMIDI API. Please use WebMIDIAPIShim " + e);
}


function onMIDISuccess(e) {
    // Speak("onmidisuccess");
    // set global variable
    global_midi = e;

    var inputs = global_midi.inputs.values();
    // loop through all inputs
    for(var input = inputs.next(); input && !input.done; input = inputs.next()){
      // listen for midi messages
      input.value.onmidimessage = onMIDIMessage;
      // listInputs(input);
    }
    // listen for connect/disconnect message
    global_midi.onstatechange = onStateChange;
}


function onMIDIMessage(event){
    var data = event.data, 
	cmd = data[0] >> 4,
	channel = data[0] & 0xf,
	type = data[0], // ignore [inconsistent between devices]
	note = data[1], 
	velocity = data[2];
					
    if (velocity) {
	    noteOn(note, velocity);
	}
	else{
	    noteOff(note, velocity);
	}
	// log('data', data, 'cmd', cmd, 'channel', channel);
	// logger(keyData, 'key data', data);
}


function noteOn(note, velocity) {
    Speak("Note on " + note.toString() + ", " + velocity.toString());
}


function noteOff(note, velocity) {
    Speak("Note off " + note.toString() + ", " + velocity.toString());
}


function onStateChange(event){
	//		var port = event.port, state = port.state, name = port.name, type = port.type;
	//		device.textContent = name.replace(/port.*/i, '');
	//		showMIDIPorts(midi);
	//		if(type == "input")
	//			log("name", name, "port", port, "state", state);
    // Speak("Midi state change");
}

console.log("midi defined");
