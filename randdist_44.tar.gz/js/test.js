"use strict"; 

var test_a = "test string 1";

function test_b() {

    return ("test string 2");
}
